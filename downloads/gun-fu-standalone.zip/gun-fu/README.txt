GUN FU - standalone copy (from retroworld.eu.cc)

Open index.html in Chrome, Edge or Firefox. Keep the "assets" folder next to it (it holds the music and sound effects).
Controls: keyboard + mouse, gamepad, or touch. See HOW TO PLAY in the menu (keyboard / touch / controller tabs).
Tip: if you open it straight from a folder, sound effects may fall back to the built-in synth. For full audio, run a tiny local server in this folder:
  python3 -m http.server 8000   then open http://localhost:8000
